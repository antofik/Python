# forkit.js

An experimental animated ribbon which reveals a curtain of additional content.

Curious about how this looks in action? [Check out the demo page](http://lab.hakim.se/forkit-js/).

# License

MIT licensed

Copyright (C) 2012 Hakim El Hattab, http://hakim.se